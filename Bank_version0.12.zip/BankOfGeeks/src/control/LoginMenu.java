/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginMenu extends JPanel implements ActionListener {

    private JTextField tfName = new JTextField("Administrator", 15);
    private JPasswordField pfPassword = new JPasswordField("Password", 15);
    private JButton btLogIn = new JButton("Belépés");
    //private JTextArea jta = new JTextArea();
    private JLabel lbMessage = new JLabel();
    private String windowTitle = "Belépés banki alkalmazásba";
    private String lbCustomText = "valami";
    private JButton btExit = new JButton("Kilépés");

    public LoginMenu() {

        JPanel panel = new JPanel();
        panel.add(new JLabel("Felhasználónév: "));
        panel.add(tfName);
        panel.add(new JLabel("Jelszó: "));
        panel.add(pfPassword);
        panel.add(btLogIn);
        JPanel panelButton = new JPanel();
        panelButton.add(btLogIn);
        panelButton.add(btExit);
        btLogIn.addActionListener(this);
        btExit.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) { // pwd mezo
        //  MyAppUser myAppUser = new MyAppUser(tfName.getText(), String.valueOf(pfPassword.getPassword())
        // );
        // jta.setText(jta.getText() + myAppUser.toString() + "\n"); teszteléshez
        if (e.getSource() == btLogIn) {

            errorMessage("Hibás felhasználónév/jelszó!");
        }

        if (e.getSource() == btExit) {

            System.exit(0);
        }
    }

    private void errorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, " Adatbeviteli hiba!", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        new LoginMenu();
    }
}
