package pojos;

import java.io.Serializable;


public class Account implements Serializable {
    
}
