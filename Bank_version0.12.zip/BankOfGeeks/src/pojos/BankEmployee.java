package pojos;

import java.io.Serializable;


public class BankEmployee extends User implements Serializable{
 
    public BankEmployee(String name, String password) {
        this.name = name;
        this.password = password;
    }
   
}