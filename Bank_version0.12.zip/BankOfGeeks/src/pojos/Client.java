package pojos;

import java.io.Serializable;



public class Client extends User implements Serializable {

    Account accounts;
    
    public Client(String name, String password) {
        this.name = name;
        this.password = password;
    }
    
}
