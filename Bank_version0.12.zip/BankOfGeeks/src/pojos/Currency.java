package pojos;


abstract public class Currency {
       String code;
       double valueInHUF;


}
