package pojos;


public class Euro extends Currency {
    public static final double VALUE = 322.4D;
    
    public Euro(){
        super();
        code = "EUR";
        valueInHUF = VALUE;
        
    }  
}