package pojos;


public class UsaDollar extends Currency {
    public static final double VALUE = 265.5;
    
    public UsaDollar(){
        super();
        code = "HUF";
        valueInHUF = VALUE;
        
    }
}