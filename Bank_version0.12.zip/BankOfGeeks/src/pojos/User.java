package pojos;


public class User {

    String name;
    String password;
    
}
