package view;

import control.LoginMenu;
import control.utils.HttpConnection;
import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;


public class Display {

    
    private JTextField tfName = new JTextField("Administrator", 15);
    private JPasswordField pfPassword = new JPasswordField("Password", 15);
    private JButton btLogIn = new JButton("Belépés");
    //private JTextArea jta = new JTextArea();
    private JLabel lbMessage = new JLabel();
    private String windowTitle = "Belépés banki alkalmazásba";
    private String lbCustomText = "valami";
    private JButton btExit = new JButton("Kilépés");
    
    
    
    public Display(final String filename) throws Exception {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame editorFrame = new JFrame("BANK OF GEEKS");
                editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                BufferedImage image = null;
                try {
                    image = ImageIO.read(new File(filename));
                } catch (Exception e) {
                    e.printStackTrace();
                    System.exit(1);
                }
                ImageIcon imageIcon = new ImageIcon(image);
                JLabel jLabel = new JLabel();
                jLabel.setIcon(imageIcon);
                editorFrame.getContentPane().add(jLabel, BorderLayout.NORTH);


                
                
        JPanel panel = new JPanel();
        panel.add(new JLabel("Felhasználónév: "));
        panel.add(tfName);
        panel.add(new JLabel("Jelszó: "));
        panel.add(pfPassword);
        panel.add(btLogIn);
        JPanel panelButton = new JPanel();
        panelButton.add(btLogIn);
        panelButton.add(btExit);
                editorFrame.add(panel);
                
                
                
                
                
                editorFrame.pack();
                editorFrame.setLocationRelativeTo(null);
                editorFrame.setVisible(true);
            }
        });
    }
    
    
     public void printStartScreen () throws Exception{
        
        List <String> webContent = HttpConnection.getWebsiteContentasList("http://hidegver.nhely.hu/BankOfGeeks/BankTitleScreen.txt");
        
         System.out.println();
        for(String item : webContent){
            System.out.print(item);
            Thread.sleep(100);
        }
        
    }
    
    
}
