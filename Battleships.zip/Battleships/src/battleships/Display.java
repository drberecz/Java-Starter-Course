package battleships;

import static battleships.Battleships.BOARD_DIM;
import static battleships.Battleships.names;

public class Display {

    public static final String[] INFO = {
        "    JELMAGYARÁZAT:",
        "    * - saját hajó",
        "    X - találat",
        "    ° - mellé"
    //   "    ~ - süllyedt"

    };

    public static void drawLineHalf(char[][] board, int y, boolean hideShips) {

        char first = (y >= 10) ? '1' : ' ';
        System.out.print(first);
        for (int x = 0; x <= BOARD_DIM; x++) {
            char tmp = board[y][x];
            if (hideShips && tmp == '*') {
                tmp = '.';
            }
            String str = tmp + " ";
            System.out.print(str);
        }

    }

    public static void showBoard(char[][] board, char[][] boardOther) {

        int padding = (BOARD_DIM >= 5) ? BOARD_DIM / 2 : 0;

        System.out.print("\n " + names[1]);
        for (int i = 0; i < (13 - names[1].length()) + padding; i++) {
            System.out.print(" ");
        }
        System.out.println(names[2] + "\n");

        for (int y = 0; y <= BOARD_DIM; y++) {

            drawLineHalf(board, y, false);
            System.out.print("  |  ");
            drawLineHalf(boardOther, y, true);

            if (y < INFO.length) {
                System.out.print(INFO[y]);
            }
            System.out.println();
        }
    }

    public static void printDelayed(String str) {

        for (int i = 0; i < str.length(); i++) {
            System.out.print(str.charAt(i));
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }

    }

}
