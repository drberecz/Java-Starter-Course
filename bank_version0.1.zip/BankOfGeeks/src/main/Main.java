package main;

import control.utils.HttpConnection;
import control.utils.HttpDownloader;
import database.DataBase;
import java.util.Scanner;
import pojos.Client;
import view.Display;


public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {

        DataBase dBase = new DataBase();
        Display display = HttpDownloader.downloadImage();
        display.printStartScreen();
        
        System.out.println("\n\n\nEzek a BANK eladasi arfolyamai");
        HttpConnection.harvestWebsite("http://api.napiarfolyam.hu/?valuta=usd");
        
        
        
        System.out.println("\n\nEZEk a nevek vannak az adatbazisban:");
        dBase.printClients();

        String inputLine = "";
        do {
            System.out.println("\n\nird be a tarolando Kliens nevet, exit-re vege");
            inputLine = sc.nextLine();
            if (inputLine != null) {
                dBase.addClient(inputLine, new Client());
            }

        } while (!"exit".equals(inputLine.toLowerCase()));

    }

}
