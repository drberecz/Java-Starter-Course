package model;


public interface Balance {
    
}
