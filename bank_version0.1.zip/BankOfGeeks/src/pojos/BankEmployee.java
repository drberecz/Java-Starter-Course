package pojos;

import java.io.Serializable;


public class BankEmployee extends User implements Serializable{
    
}