package pojos;

import java.io.Serializable;



public class Client extends User implements Serializable {
    
}
