package pojos;


public class Currency {
    
}
