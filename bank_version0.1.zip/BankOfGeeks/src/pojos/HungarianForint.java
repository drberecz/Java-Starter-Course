package pojos;


public class HungarianForint extends Currency {
    
}