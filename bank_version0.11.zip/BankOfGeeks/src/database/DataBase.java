package database;

import control.utils.FileIO;
import enums.UserType;
import java.util.HashMap;
import java.util.Map;
import pojos.Client;

public class DataBase {

    public final static String FILENAME_CLIENT = "client.ser";
    public final static String FILENAME_BANKEMPLOYEE = "employee.ser";
    private Map<String, Client> mapOfClients = new HashMap<>();

    
public DataBase(){
    FileIO.createDir();
        try{

        mapOfClients = (Map<String, Client>) FileIO.readFile(FILENAME_CLIENT);
        }catch(Exception e){
            System.out.println("Database UZENET>AJJAJJJ, kis problema van: "+ e);
            fillWithDummyValues();
        }
        FileIO.writeFile(mapOfClients, FILENAME_CLIENT);
}
    
    
    public void printClients() {

        for (Map.Entry<String, Client> entry : mapOfClients.entrySet()) {
            System.out.printf("Neve : %s , Mi van Benne?: %s %n", entry.getKey(), entry.getValue());
        }
    }

    public void addClient(String name, Client client) {

        mapOfClients.put(name, client);
        FileIO.writeFile(mapOfClients, FILENAME_CLIENT);
    }

    public Map<String, Client> getClientMap() {
        return mapOfClients;
    }

    public final void fillWithDummyValues() {

        mapOfClients.put("Bela", new Client());
        mapOfClients.put("Cecil", new Client());
        mapOfClients.put("Denes", new Client());
    }

        
    

}







