package enums;

public enum UserType{
    CLIENT, BANKEMPLOYEE
}
