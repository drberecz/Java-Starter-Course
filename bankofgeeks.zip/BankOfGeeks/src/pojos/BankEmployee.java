package pojos;


public class BankEmployee extends User{
    
}