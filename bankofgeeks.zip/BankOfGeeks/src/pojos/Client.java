package pojos;


public class Client extends User{
    
}
