package pojos;


public class Euro extends Currency {
    
}