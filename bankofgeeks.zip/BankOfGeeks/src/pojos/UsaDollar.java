package pojos;


public class UsaDollar extends Currency {
    
}