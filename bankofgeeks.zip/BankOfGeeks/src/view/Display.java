package view;


public class Display {
    
}
