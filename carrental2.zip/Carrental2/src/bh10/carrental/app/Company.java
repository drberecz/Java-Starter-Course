package bh10.carrental.app;

import bh10.carrental.controller.CarRentalController;
import bh10.carrental.model.CompanyModel;
import bh10.carrental.model.Customer;
import bh10.carrental.service.CarRentalService;
import bh10.carrental.service.InitializationService;
import bh10.carrental.view.console.ConsoleView;
import bh10.carrental.view.interfaces.CarRentalView;
import bh10.carrental.view.swing.MainWindow;
import bh10.carrental.view.swing.WebViewSwing;

public class Company {

    public static String currentCustomerType;

    private static Customer customer;

    public static void main(String[] args) {
        
        CarRentalController controller = new CarRentalController();
        CarRentalService rentalService = new CarRentalService();
       // CarRentalView view = new SwingView();
      //  CarRentalView view = new ConsoleView();
        CompanyModel model = new CompanyModel();
        
        rentalService.setModel(model);
        
        InitializationService.initalizeSites(model.getSites());
        
        controller.setCarRentalService(rentalService);
      //  controller.setView(view);
        
      //  view.setController(controller);
       
        
      //  view.display();
      
        WebViewSwing view = new WebViewSwing();
      
        MainWindow mw = new MainWindow();
      view.setMainWindowRef( mw) ;
      view.setController(controller);
      controller.setView(view);
      view.display();
    }

}
