package bh10.carrental.controller;

import bh10.carrental.model.Car;
import bh10.carrental.model.Site;
import bh10.carrental.service.CarRentalService;
import bh10.carrental.view.interfaces.CarRentalView;
import java.util.List;

public class CarRentalController {

    private CarRentalView view;

    private CarRentalService carRentalService;

    public void setView(CarRentalView view) {
        this.view = view;
    }

    public CarRentalService getCarRentalService() {
        return carRentalService;
    }

    public void setCarRentalService(CarRentalService carRentalService) {
        this.carRentalService = carRentalService;
    }

    public List<Car> getCarsForSiteId(Integer id) {
        return carRentalService.getCarsForSiteId(id);
    }

    public List<Site> getSites() {
        return carRentalService.getSites();
    }

    public List<Car> getCarsQueryCost(Integer SiteId, int cost) {
        List filteredList
                = carRentalService.collectCarsCheaperThanQuery(SiteId, cost);
        return filteredList;

    }
    
 

}
















