/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.controller;

public enum HtmlTag {
    H1, H2, PRE, P, SPAN ,A , DIV, END_DIV
}
