package bh10.carrental.model;

public class BusinessCustomer extends Customer {
    
    public static final Integer MINIMUM_LIMIT_OF_CAR_RENTAL = 5;

    public BusinessCustomer(String name, Integer customerId, Double discount) {
        super(name, customerId, 10.0);
    }

}
