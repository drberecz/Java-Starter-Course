package bh10.carrental.model;

public class Car {

    public static final String[] CAR_TYPES = {"Audi", "Nissan", "BMW", "VolksWagen", "Lada","Skoda","Kia", "Trabant"};
    public static final Integer[] DAILY_RENTAL_COST = {15000, 10000, 14000, 6500, 1000, 5500, 6300, 920};

    private String type;

    private Integer price;

    private String plateNumber;

    private boolean isRented;

    public Car() {
    }

    public Car(String type, Integer price, String plateNumber, boolean isRented) {
        this.type = type;
        this.price = price;
        this.plateNumber = plateNumber;
        this.isRented = isRented;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Car " + " type=" + type + ", price=" + price + ", plateNumber=" + plateNumber + ", isRented=" + isRented;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public boolean isIsRented() {
        return isRented;
    }

    public void setIsRented(boolean isRented) {
        this.isRented = isRented;
    }

}
