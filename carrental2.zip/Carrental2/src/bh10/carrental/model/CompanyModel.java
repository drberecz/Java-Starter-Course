package bh10.carrental.model;

import java.util.ArrayList;
import java.util.List;

public class CompanyModel {

    private List<Site> sites = new ArrayList<>();

    public List<Site> getSites() {
        return sites;
    }

    public void setSites(List<Site> sites) {
        this.sites = sites;
    }

}
