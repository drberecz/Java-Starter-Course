package bh10.carrental.model;

public abstract class Customer {
    
    public static final String PLATINA = "PLATINA";
    public static final String BUSINESS = "BUSINESS";
    public static final String PERSONAL = "PERSONAL";
    
    private String name;

    private Integer customerId;

    private Double discount;

    public Customer(String name, Integer customerId, Double discount) {
        this.name = name;
        this.customerId = customerId;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

}
