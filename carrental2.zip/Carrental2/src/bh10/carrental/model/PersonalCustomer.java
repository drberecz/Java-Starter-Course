package bh10.carrental.model;

import bh10.carrental.model.Customer;

public class PersonalCustomer extends Customer {

    public PersonalCustomer(String name, Integer customerId, Double discount) {
        super(name, customerId, 0.0);
    }

}
