package bh10.carrental.model;

public class PlatinaCustomer extends PersonalCustomer {

    public PlatinaCustomer(String name, Integer customerId, Double discount) {
        super(name, customerId, 7.5);
    }

}
