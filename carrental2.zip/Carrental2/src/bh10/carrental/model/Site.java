package bh10.carrental.model;

import java.util.List;

public class Site {

    private String address;

    private List<Car> cars;

    private Integer siteId;

    public Site(String address, List<Car> cars, Integer siteId) {
        this.address = address;
        this.cars = cars;
        this.siteId = siteId;
    }
    
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    @Override
    public String toString() {
        
        return "Telephely (" + address + ", "+ siteId + ")";
    }
    
    

}
