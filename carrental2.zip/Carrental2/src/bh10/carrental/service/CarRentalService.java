package bh10.carrental.service;

import bh10.carrental.model.Car;
import bh10.carrental.model.CompanyModel;
import bh10.carrental.model.Site;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CarRentalService {

    private CompanyModel model;

    public CompanyModel getModel() {
        return model;
    }

    public void setModel(CompanyModel model) {
        this.model = model;
    }

    public List<Car> getCarsForSiteId(Integer id) {
        return model.getSites().get(id).getCars();
    }

    public List<Site> getSites() {
        return model.getSites();
    }

    public List<Car> collectCarsCheaperThanQuery(int siteId, int query) {

        List<Car> originalList = this.getCarsForSiteId(siteId);
        Stream<Car> filtered_data = originalList.stream().filter(c -> c.getPrice() <= query);

        List<Car> filteredList = filtered_data.collect(Collectors.toList());

        return filteredList;
    }

}
