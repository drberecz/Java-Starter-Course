package bh10.carrental.service;

import bh10.carrental.model.Car;
import bh10.carrental.model.Site;
import java.util.ArrayList;
import java.util.List;

public class InitializationService {
    
    
    private static final int CARS_AVAILABLE = 20;
    
    

    public static void initializeSite(Site site) {
        List<Car> carList = site.getCars();
        for (int i = 0; i < CARS_AVAILABLE; i++) {
            Car car = getRandomCar();
            carList.add(car);
        }
    }

    public static Car getRandomCar() {
        Car car = new Car();
        int randomNumber = (int) (Math.random() * Car.CAR_TYPES.length);
        car.setType(Car.CAR_TYPES[randomNumber]);
        car.setPrice(Car.DAILY_RENTAL_COST[randomNumber]);
        car.setIsRented( (Math.random()>0.6D) );
        
        car.setPlateNumber(generatePlateNumber());
        return car;
    }

    public static void initalizeSites(List<Site> sites) {
        for (int i = 0; i < 3; i++) {
            Site site = new Site("Deres" + i, new ArrayList<>(), i);
            initializeSite(site);
            sites.add(site);
        }
    }

    private static String generatePlateNumber (){
        
        final int NUMPLATE_ALPHABETS = 3;
        final int dictionary = 'Z' - 'A';
        StringBuilder numPlate = new StringBuilder();
        
        for (int i = 0; i < NUMPLATE_ALPHABETS; i++) {
            numPlate.append( (char) ((Math.random()*dictionary) + 'A'));
        }
        numPlate.append('-');
        
        Integer threeDigits = (int)(Math.random()*900)+100;
        numPlate.append(threeDigits.toString());
        
        return numPlate.toString();
    }
    
    
}

































