package bh10.carrental.service;

import bh10.carrental.model.Customer;
import java.util.Map;

public class RentalPriceCalculatorServie {
    
    private static final double MAX_DISCOUNT = 30.0;

    public static double calculateRentalPrice(Customer customer, Map<String, Integer> requestedAmountByCarType) {
        
        return 0.0;
    }
}
