package bh10.carrental.view.console;

import bh10.carrental.app.Company;
import bh10.carrental.controller.CarRentalController;
import bh10.carrental.model.Car;
import bh10.carrental.model.Customer;
import bh10.carrental.model.Site;
import bh10.carrental.view.interfaces.CarRentalView;
import bh10.carrental.view.swing.TableDemo;
import java.util.List;
import java.util.Scanner;

public class ConsoleView implements CarRentalView {

    private static final Scanner sc = new Scanner(System.in);

    private CarRentalController controller;

    public CarRentalController getCvc() {
        return controller;
    }

    private void displayMenuItems() {
        System.out.println("1: Telephelyek list\u00e1z\u00e1sa");
        System.out.println("2: Adott telephelyen k\u00f6lcs\u00f6n\u00f6zhet\u0151 aut\u00f3k list\u00e1z\u00e1sa");
        System.out.println("3: Aut\u00f3t\u00edpusok \u00e1rainak megtekint\u00e9se");
        System.out.println("4: K\u00f6lcs\u00f6nz\u00e9s");
        System.out.println("-1: Kil\u00e9p\u00e9s");
    }

    private void displayMenuItemsCarList() {
        System.out.println("1: Összes telephelyen lévő autót listázza");
        System.out.println("2: Csak a megadott összegnél olcsóbb autókat listázza");
        System.out.println("-1: Kil\u00e9p\u00e9s");
    }

    public void displayCarListQuerySelectors(int siteId) {
        int menuChoice = 0;
        do {
            displayMenuItemsCarList();
            menuChoice = sc.nextInt();
            switch (menuChoice) {

                case 1:

                    displayCarsForSiteId(siteId);
                    TableDemo.createTableForMyUser(
                            controller.getCarsForSiteId(siteId),
                            "Összes Autó a Telephelyen");
                    break;
                case 2:
                    System.out.println("Írja be a határszámot: ");
                    int rentalCost = sc.nextInt();
                    TableDemo.createTableForMyUser(
                            controller.getCarsQueryCost(siteId, rentalCost),
                            rentalCost + " Ft.-nál olcsóbb Autók Listája");

                default:
                    break;
            }
        } while (menuChoice != -1);
    }

    public void displayMenu() {
        int menuChoice = 0;
        do {
            displayMenuItems();
            menuChoice = sc.nextInt();
            switch (menuChoice) {
                case 1:
                    displaySites();
                    break;
                case 2:
                    System.out.println("Melyik telephelyre k\u00edv\u00e1ncsi?");
                    int siteId = sc.nextInt();
                    displayCarListQuerySelectors(siteId);
                    break;
                case 3:
                    break;
                case 4:
                    break;
                default:
                    break;
            }
        } while (menuChoice != -1);
    }

    public void displaySites() {
        List<Site> sites = controller.getSites();
        for (Site site : sites) {
            System.out.println(site);
        }
    }

    public void displayLogin() {
        System.out.println("K\u00e9rem l\u00e9pjen be: 1=Personal, 2=Platina, 3=Business");
        int customerType = sc.nextInt();
        switch (customerType) {
            case 1:
                Company.currentCustomerType = Customer.PERSONAL;
                break;
            case 2:
                Company.currentCustomerType = Customer.PLATINA;
                break;
            case 3:
                Company.currentCustomerType = Customer.BUSINESS;
                break;
        }
    }

    private void displayCarsForSiteId(int siteId) {
        List<Car> carList = controller.getCarsForSiteId(siteId);

        System.out.println("----Telephely : " + siteId + "----");

        for (Car car : carList) {
            System.out.println("|" + car);
        }

    }

    public String getCarListAsString(Site site) {
        StringBuilder sb = new StringBuilder();

        List<Car> carList = site.getCars();

        for (Car car : carList) {
            sb.append(carList.indexOf(car));
            sb.append(" aut\u00f3 r\u00e9szletei: ");
            sb.append(car);
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public void display() {
        displayLogin();
        displayMenu();
    }

    @Override
    public void setController(CarRentalController controller) {
        this.controller = controller;
    }

}
