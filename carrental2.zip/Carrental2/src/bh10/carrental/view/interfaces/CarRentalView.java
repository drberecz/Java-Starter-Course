/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.view.interfaces;

import bh10.carrental.controller.CarRentalController;

/**
 *
 * @author kopacsi.krisztian
 */
public interface CarRentalView {
    
    public void display();
    
    public void setController(CarRentalController controller);
}
