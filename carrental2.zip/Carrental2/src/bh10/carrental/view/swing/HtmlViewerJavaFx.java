/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.view.swing;

/**
 *
 * @author mantis
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebEvent;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
/*from w ww .  jav a 2 s. c o  m*/
public class HtmlViewerJavaFx  extends Application{ 
    @Override
  public void start(final Stage stage) {
    stage.setWidth(400);
    stage.setHeight(500);
    Scene scene = new Scene(new Group());

    final WebView browser = new WebView();
    final WebEngine webEngine = browser.getEngine();

    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setContent(browser);

    browser.getEngine().setOnAlert((WebEvent<String> wEvent) -> {
      System.out.println("Ezt mondja a weboldal>  " + wEvent.getData());
    });

    webEngine.load("http://hidegver.nhely.hu/carrental/index.html");

    scene.setRoot(scrollPane);

    stage.setScene(scene);
    stage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}






