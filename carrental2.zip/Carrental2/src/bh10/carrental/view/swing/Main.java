/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.view.swing;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebEvent;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
/*from w ww .  jav a 2 s. c o  m*/
public class Main extends Application {
  @Override
  public void start(final Stage stage) {
    stage.setWidth(800);
    stage.setHeight(600);
    Scene scene = new Scene(new Group());

    final WebView browser = new WebView();
    final WebEngine webEngine = browser.getEngine();

    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setContent(browser);

    browser.getEngine().setOnAlert(new EventHandler<WebEvent<String>>() {
        @Override
        public void handle(WebEvent<String> wEvent) {
            System.out.println("Ezt mondja a weboldal>  " + wEvent.getData());
            
            URL myUrl = null;
File myFile=new File("./assets/lists.html");
            try {
                myUrl = myFile.toURI().toURL();
            } catch (MalformedURLException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            

//URL url =  getClass().getResource("./lists.html");
webEngine.load(myUrl.toExternalForm());

System.out.println("URL: " + myUrl.toString());
//webEngine.loadContent("<html><body><b>JavaFX<br></b><b>JavaXFX<br></b><b>JavaXXX<br></b></body></html>");
        }
    });

   // webEngine.load("http://hidegver.nhely.hu/carrental/index.html");
webEngine.load("http://ibdhost.com/help/html/");
   
   
//webEngine.loadContent("<html><body><b>JavaFX<br></b><b>JavaXFX<br></b><b>JavaXXX<br></b></body></html>");
    
    
    scene.setRoot(scrollPane);

    stage.setScene(scene);
    stage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}