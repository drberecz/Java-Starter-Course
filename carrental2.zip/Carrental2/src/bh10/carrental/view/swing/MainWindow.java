/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.view.swing;


import bh10.carrental.controller.HtmlTag;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;


public class MainWindow {



    private static String content = "NINCS HiR";
    private static String lastInput = "";
private static JEditorPane jEditorPane = null;    
    

    
//    public static void main(String[] args) throws InterruptedException {
//        invokeConstructor();
//        
//        String input = "";
//        do{
//            input = wait4Input();
//            updateWindow(HtmlTag.P, input);
//
//        }while ( !"x".equals(input));
//        
//    }

    public MainWindow() {
//        SwingUtilities.invokeLater(new Runnable() {
//            
//
   //         public void run() {


            // create jeditorpane
            jEditorPane = new JEditorPane();

            // make it read-only
            jEditorPane.setEditable(false);

            // create a scrollpane; modify its attributes as desired
            JScrollPane scrollPane = new JScrollPane(jEditorPane);

            // add an html editor kit
            HTMLEditorKit kit = new HTMLEditorKit();
            jEditorPane.setEditorKit(kit);

            // add some styles to the html
            StyleSheet styleSheet = kit.getStyleSheet();
            styleSheet.addRule("body {color:#000; font-family:times; margin: 4px; }");
            styleSheet.addRule("h1 {color: blue;}");
            styleSheet.addRule("h2 {font : 14px monaco; color: #880044;}");
            styleSheet.addRule("pre {font : 14px monaco; color : black; background-color : #99fa66; }");
            styleSheet.addRule("p { width:400px;  font : 16px monaco; color : black; border-style: solid; background-color : #ccccaa; }");
            styleSheet.addRule("span {font : 16px monaco; color : #ffaa00; background-color : #555555; }");
            styleSheet.addRule("div { width:450px; margin: 0px 10px 0px 0px; padding: 15px 15px 15px 15px; height: auto; width: auto; border: 1px solid #ddd; border-radius: 4px 4px 4px 4px; background-color: #f4f4f4; display:inline-block; }");              
                
            // create some simple html as a string
            String htmlString = "<html>\n"
                    + "<body>\n"
                    + "<pre> Mi VAn MAAA"
                    + "</body>\n";



            // create a document, set it on the jeditorpane, then add the html
            Document doc = kit.createDefaultDocument();
            jEditorPane.setDocument(doc);
            jEditorPane.setText(htmlString);

 
            
            
                  jEditorPane.addHyperlinkListener((HyperlinkEvent e) -> {
                    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                        System.out.println("HTML link clicked!");
                        String strVal = e.getURL().toString();
                        lastInput = strVal.replaceAll("[^\\d.]", "");

                    }
                });          
            
            
            
            
            
              //  JTextArea JInput = new JTextArea();
              JLabel jInputLabel = new JLabel("INPUT");
JTextField textField = new JTextField(16);            
JPanel jInputPanel = new JPanel();
jInputPanel.add(jInputLabel);
jInputPanel.add(textField);
  Action action = new AbstractAction()
{
    @Override
    public void actionPerformed(ActionEvent e)
    {

       lastInput = textField.getText();

        textField.setText("");
    }
};


textField.addActionListener( action );
                
                
                
            // now add it all to a frame
            JFrame j = new JFrame("CAR RENTAL");
            Font font = new Font("DejaVu Sans Mono", Font.PLAIN, 24); 
            //jEditorPane.setFont(font);
            textField.setFont(font);




scrollPane.scrollRectToVisible(new Rectangle(0,jEditorPane.getBounds(null).height,1,1));
            
            
            j.getContentPane().add(scrollPane, BorderLayout.CENTER);
            j.getContentPane().add(jInputPanel, BorderLayout.NORTH);

            // make it easy to close the application
            j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // display the frame
            j.setSize(new Dimension(1000, 600));

            // pack it, if you prefer
            //j.pack();
            // center the jframe, then make it visible
            j.setLocationRelativeTo(null);
            j.setVisible(true);

    }
      ///  });
//}
    
    public static String wait4Input() throws InterruptedException{
        
        while( "".equals(lastInput)){
            Thread.sleep(300);

        }
        String input = lastInput.trim();
        lastInput = "";
        
        return input;
    }

    
    public  void clearWindow(){
        content = "";
       jEditorPane.setText(content);
    }
    
    
    
    public static void updateWindow(HtmlTag tag, String newcontent ){

        String tagPre;
        String tagPost;
        
        switch(tag){
            
            case H1:
                tagPre = "<h1>";
                tagPost="</h1>";
            break;
            case H2:
                tagPre = "<h2>";
                tagPost="</h2>";
            break;
            case P:
                tagPre = "<p>";
                tagPost="</p>";
            break;
            case PRE:
                tagPre = "<pre>";
                tagPost="</pre>";
            case SPAN:
                tagPre = "<span>";
                tagPost="</span>";
            break;
            case A:
                tagPre = "<p><a";
                tagPost="</a></p>";
            break;
            case DIV:
                tagPre = "<div>";
                tagPost="";
            break;
            case END_DIV:
                tagPre = "</div>";
                tagPost="";
            break;
            default:
                tagPre = "";
                tagPost="";
            break;
        }
        
        
        
        
        
        content += tagPre + newcontent + tagPost;
        jEditorPane.setText(content);

int len = jEditorPane.getDocument().getLength();
jEditorPane.setCaretPosition(len);        
}


    
    
}

