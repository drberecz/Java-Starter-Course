package bh10.carrental.view.swing;

import bh10.carrental.controller.CarRentalController;
import bh10.carrental.view.interfaces.CarRentalView;

public class SwingView implements CarRentalView {

    CarRentalController controller;

    @Override
    public void display() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setController(CarRentalController controller) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
