package bh10.carrental.view.swing;

import bh10.carrental.controller.CarRentalController;
import bh10.carrental.model.Car;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * TableDemo is just like SimpleTableDemo, except that it uses a custom
 * TableModel.
 */
public class TableDemo extends JPanel {

    private boolean DEBUG = false;
    private static JFrame frame;

    public TableDemo(List<Car> cars) {
        super(new GridLayout(1, 0));

        JTable jt = new JTable(new MyTableModel(cars));
        jt.setPreferredScrollableViewportSize(new Dimension(600, 400));

        jt.setCellSelectionEnabled(true);
        ListSelectionModel select = jt.getSelectionModel();
        select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        select.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {

                Object col = jt.getColumnClass(WIDTH);
                System.out.println(col.toString());
                //jt.setValueAt(e, 0, WIDTH);


            }
        });

        //Create the scroll pane and add the table to it.
        JScrollPane scrollPane = new JScrollPane(jt);

        //Add the scroll pane to this panel.
        add(scrollPane);
    }

    class MyTableModel extends AbstractTableModel {

        private String[] columnNames = {"TIPUS", "  ARA  ", "Rendszam", " FOGLALT?"};
        private Object[][] data = null;//{ { "Mary", "Campione", "Snowboarding", new Integer(5), true} };

        MyTableModel(List<Car> cars) {
            Object[][] tmpdata = new Object[cars.size()][columnNames.length];
            for (int i = 0; i < cars.size(); i++) {
                Car currCar = cars.get(i);

                tmpdata[i][0] = currCar.getType();
                tmpdata[i][1] = currCar.getPrice();
                tmpdata[i][2] = currCar.getPlateNumber();
                tmpdata[i][3] = currCar.isIsRented();

            }
            data = tmpdata;

        }

//    private String[] columnNames = { "First Name", "Last Name", "Sport",
//        "# of Years", "Vegetarian" };
//
//    private Object[][] data = {
//        { "Mary", "Campione", "Snowboarding", new Integer(5), true},
//        { "Alison", "Huml", "Rowing", new Integer(3), new Boolean(true) },
//        { "Kathy", "Walrath", "Knitting", new Integer(2),
//            new Boolean(false) },
//        { "Sharon", "Zakhour", "Speed reading", new Integer(20),
//            new Boolean(true) },
//        { "Philip", "Milne", "Pool", new Integer(10),
//            new Boolean(false) } };
        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public int getRowCount() {
            return data.length;
        }

        @Override
        public String getColumnName(int col) {
            return columnNames[col];
        }

        @Override
        public Object getValueAt(int row, int col) {
         //   System.out.println("row: "+ row + "col: " + col);
            return data[row][col];
        }

        /*
     * JTable uses this method to determine the default renderer/ editor for
     * each cell. If we didn't implement this method, then the last column
     * would contain text ("true"/"false"), rather than a check box.
         */
        @Override
        public Class getColumnClass(int c) {
            return getValueAt(0, c).getClass();
        }

        /*
     * Don't need to implement this method unless your table's editable.
         */
        @Override
        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.
            return false;
//            if (col < 2) {
//                return false;
//            } else {
//                return true;
//            }
        }

        /*
     * Don't need to implement this method unless your table's data can
     * change.
         */
        @Override
        public void setValueAt(Object value, int row, int col) {
            if (DEBUG) {
                System.out.println("Setting value at " + row + "," + col
                        + " to " + value + " (an instance of "
                        + value.getClass() + ")");
            }

            data[row][col] = value;
            fireTableCellUpdated(row, col);

            if (DEBUG) {
                System.out.println("New value of data:");
                printDebugData();
            }
        }

        private void printDebugData() {
            int numRows = getRowCount();
            int numCols = getColumnCount();

            for (int i = 0; i < numRows; i++) {
                System.out.print("    row " + i + ":");
                for (int j = 0; j < numCols; j++) {
                    System.out.print("  " + data[i][j]);
                }
                System.out.println();
            }
            System.out.println("--------------------------");
        }
    }

    /**
     * Create the GUI and show it. For thread safety, this method should be
     * invoked from the event-dispatching thread.
     */
    private static void createAndShowGUI(List<Car> car, String msg) {
    
        Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
        System.out.println("EZ A MERET: " + threadSet.size());

//Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
         frame = new JFrame(msg);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //Create and set up the content pane.
        TableDemo newContentPane = new TableDemo(car);
        newContentPane.setOpaque(true); //content panes must be opaque
        //frame.setContentPane(newContentPane);
        frame.add(newContentPane, BorderLayout.CENTER);

        JPanel mainPanel = new JPanel();
        JButton b1 = new JButton("EGYIK GOMB");
        JButton b2 = new JButton("BEZAR");
        JLabel  selection = new JLabel("NINCS AUTO KIVALASZTVA");
        Font font = new Font(Font.MONOSPACED, Font.PLAIN, 18);
        selection.setFont(font);
        
        b1.addActionListener((ActionEvent arg0) -> {
            selection.setText(arg0.toString());
        });
        b2.addActionListener((ActionEvent arg0) -> {
            frame.dispose();
        });

        mainPanel.add(b1);
        mainPanel.add(b2);
        mainPanel.add(selection);
        frame.getContentPane().add(mainPanel, BorderLayout.PAGE_END);

        // frame.getContentPane().add(newContentPane, BorderLayout.CENTER);
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void createTableForMyUser(List<Car> car, String msg) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        
        if (frame!=null) {
            frame.dispose();
            System.out.println("DISPOSED");
        }
        Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
        System.out.println("EZ A MERET: " + threadSet.size());
        
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI(car, msg);
            }
        });
    }
}
