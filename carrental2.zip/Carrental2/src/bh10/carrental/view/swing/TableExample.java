package bh10.carrental.view.swing;

import java.awt.BorderLayout;
import javax.swing.*;    
import javax.swing.event.*;  
public class TableExample {    
      public static void main(String[] a) {  
            JFrame f = new JFrame("Table Example"); 
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            String data[][]={ {"101","Amit","670000"},    
                                                                       {"102","Jai","780000"},    
                                                                       {"101","Sachin","700000"}};    
                            String column[]={"ID","NAME","SALARY"};         
                            final JTable jt=new JTable(data,column);    

                            
                            
            JScrollPane sp=new JScrollPane(jt);    
            
            
            JPanel mainPanel = new JPanel();
            JButton b1 = new JButton("EGYIK");
            JButton b2 = new JButton("MASIK");
            mainPanel.add(b1);
            mainPanel.add(b2);
            f.getContentPane().add(mainPanel, BorderLayout.PAGE_START);
            
            
            f.getContentPane().add(sp, BorderLayout.CENTER);
            f.setSize(400, 400);  
            f.setVisible(true);  
          }  
        }  











