/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bh10.carrental.view.swing;

import bh10.carrental.app.Company;
import bh10.carrental.controller.CarRentalController;
import bh10.carrental.controller.HtmlTag;
import bh10.carrental.model.Car;
import bh10.carrental.model.Customer;
import bh10.carrental.model.Site;
import bh10.carrental.view.interfaces.CarRentalView;
import bh10.carrental.view.swing.TableDemo;
import java.util.List;

public class WebViewSwing implements CarRentalView {

    private CarRentalController controller;
    private MainWindow mwRef;

    public void setMainWindowRef(MainWindow mainWindowRef) {
        this.mwRef = mainWindowRef;
    }

    public CarRentalController getCvc() {
        return controller;
    }

    private void displayMenuItems() {
        mwRef.clearWindow();
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://1\">1: Telephelyek list\u00e1z\u00e1sa</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://2\">2: Adott telephelyen k\u00f6lcs\u00f6n\u00f6zhet\u0151 aut\u00f3k list\u00e1z\u00e1sa</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://3\">3: Aut\u00f3t\u00edpusok \u00e1rainak megtekint\u00e9se</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://4\">4: K\u00f6lcs\u00f6nz\u00e9s</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://-1\">-1: Kil\u00e9p\u00e9s</a>");

    }

    private void displayMenuItemsCarList() {
        mwRef.clearWindow();
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://1\">1: Összes telephelyen lévő autót listázza</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://2\">2: Csak a megadott összegnél olcsóbb autókat listázza</a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://-1\">-1: Kil\u00e9p\u00e9s</a>");
    }

    public void displayCarListQuerySelectors(int siteId) throws InterruptedException {
        int menuChoice = 0;
        do {
            displayMenuItemsCarList();
            menuChoice = Integer.parseInt(mwRef.wait4Input());
            switch (menuChoice) {

                case 1:
                    mwRef.clearWindow();
                    mwRef.updateWindow(HtmlTag.PRE, "Uj ablakban van a lista");
                    TableDemo.createTableForMyUser(
                            controller.getCarsForSiteId(siteId),
                            "Összes Autó a Telephelyen");
                    break;
                case 2:
                    mwRef.updateWindow(HtmlTag.PRE, "Írja be a határszámot: ");
                    int rentalCost = Integer.parseInt(mwRef.wait4Input());
                    TableDemo.createTableForMyUser(
                            controller.getCarsQueryCost(siteId, rentalCost),
                            rentalCost + " Ft.-nál olcsóbb Autók Listája");

                default:
                    break;
            }
                    mwRef.updateWindow(HtmlTag.DIV, "");
                    mwRef.updateWindow(HtmlTag.A,"<a href=\"http://-1\">KILEPES" );
                    mwRef.updateWindow(HtmlTag.END_DIV, "");
                    Integer.parseInt(mwRef.wait4Input());                    
                    
            
        } while (menuChoice != -1);
    }

    public void displayMenu() throws InterruptedException {
        int menuChoice = 0;
        do {
            displayMenuItems();
            menuChoice = Integer.parseInt(mwRef.wait4Input());
            switch (menuChoice) {
                case 1:
                    mwRef.clearWindow();
                    mwRef.updateWindow(HtmlTag.DIV, "");
                    mwRef.updateWindow(HtmlTag.A,"<a href=\"http://-1\">KILEPES" );
                    mwRef.updateWindow(HtmlTag.END_DIV, "");

                    displaySites();                    
                    Integer.parseInt(mwRef.wait4Input());

                    break;
                case 2:
                    mwRef.clearWindow();
                    mwRef.updateWindow(HtmlTag.H1, "Melyik telephelyre k\u00edv\u00e1ncsi?");
                    displaySites();
                    int siteId = Integer.parseInt(mwRef.wait4Input());
                    displayCarListQuerySelectors(siteId);
                    break;
                case 3:
                    break;
                case 4:
                    break;
                default:
                    break;
            }
        } while (menuChoice != -1);
    }

    public void displaySites() {
        List<Site> sites = controller.getSites();
        int itemIndex = 0;
        for (Site site : sites) {
            mwRef.updateWindow(HtmlTag.P,"<a href=\"http://" +itemIndex+"\"> " + site.toString() + "</a>" );
        }
    }

    public void displayLogin() throws InterruptedException {
        mwRef.clearWindow();
        mwRef.updateWindow(HtmlTag.DIV, "");
        mwRef.updateWindow(HtmlTag.H1, "K\u00e9rem l\u00e9pjen be:<br>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://1\"> 1=Personal </a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://2\">  2=Platina </a>");
        mwRef.updateWindow(HtmlTag.P, "<a href=\"http://3\">  3=Business </a>");
  mwRef.updateWindow(HtmlTag.END_DIV, "");
        int customerType = Integer.parseInt(mwRef.wait4Input());
        switch (customerType) {
            case 1:
                Company.currentCustomerType = Customer.PERSONAL;
                break;
            case 2:
                Company.currentCustomerType = Customer.PLATINA;
                break;
            case 3:
                Company.currentCustomerType = Customer.BUSINESS;
                break;
        }
    }

    private void displayCarsForSiteId(int siteId) {
        List<Car> carList = controller.getCarsForSiteId(siteId);

        mwRef.updateWindow(HtmlTag.H1, "----Telephely : " + siteId + "----");

        for (Car car : carList) {
            mwRef.updateWindow(HtmlTag.PRE, car.toString());
        }

    }

    public String getCarListAsString(Site site) {
        StringBuilder sb = new StringBuilder();

        List<Car> carList = site.getCars();

        for (Car car : carList) {
            sb.append(carList.indexOf(car));
            sb.append(" aut\u00f3 r\u00e9szletei: ");
            sb.append(car);
            sb.append("\n");
        }
        return sb.toString();
    }

    @Override
    public void display() {
        try {
            displayLogin();
            displayMenu();
        } catch (InterruptedException ex) {
            System.out.println("Problem: " + ex.getMessage());
        }
    }

    @Override
    public void setController(CarRentalController controller) {
        this.controller = controller;
    }

}
