package bh.jsc04;

import static bh.jsc04.Game.rMoveMarkerYX;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.Timer;

/**
 *
 * @author lborisz
 */
public class ChessBoardPrinter {
  
  private static void printABC(){
    System.out.println("    A   B   C   D   E   F   G   H");
  }
  
  
  static void printRemovedFig(int row, int num, List list){  
        for (int i =(row-num)*4; i < list.size(); i++) {
            if (i == ((row-num)*4)+4) break;
            System.out.print(list.get(i));
        }
  }
  
  
  static void printBoard(){

     // StringBuilder sbstr = new StringBuilder();
    System.out.println("  ---------------------------------      Levett Bábuk: ");
    for (int row = 1; row <= 8; row++) {
      System.out.print(row+" ");
      for (int column = 1; column <= 8; column++) {
        
      //  sbstr.append(Chess.board[row][column]);
          
        System.out.print(Chess.board[row][column] == ' ' ?  "| " + square(row+column) + " " :
                                     "| " + Chess.board[row][column] + " ");
        //\u2B1B, \u2588, \u2591
      }
      System.out.print("|       \u001B[47m");
      if ( row<=4) printRemovedFig(row, 1, Chess.figuresRemoved0);
      else         printRemovedFig(row, 5, Chess.figuresRemoved1);
      System.out.println("\u001B[0m");
      System.out.println("  ---------------------------------");
    }
    printABC();
    //  System.out.println(sbstr);
  }

  static char square(int i) {
    return i%2!=0? '\u2588' : '\u2591'; 
  }
 
  
}






class JcompChess extends JComponent  {

    
    static ArrayList<BufferedImage> image;
    static BufferedImage background;
    private static final int PREF_W = 600;
    private static final int PREF_H = 600;
    private static final int ANIM_TRSHOLD  = 150;
    
    int animCount = 0;
    static boolean routeActive = false;
    static boolean repaint = false;
  
    static double deltaY= 0;
    static double deltaX= 0;
    static double[] posYX  = { 0.0,0.0};    
    static int[] targetYX  = { -1,-1};    
    static int[] fromCoords  = {0,0};
    static int[] toCoords    = {0,0};
    static int movingFig = 0;
    static char targetFig = ' ';    
    
    
    static void calcAnimation (int y1, int x1, int y2, int x2, char fig, char target){
//36+(x-1)*48, 10+(y-1)*48, null);
        fromCoords[0] = y1;
        fromCoords[1] = x1;
        toCoords[0] = y2;
        toCoords[1] = x2;
        targetFig = target;
        posYX[0] = 10+(y1-1)*48;
        posYX[1] = 36+(x1-1)*48;
        targetYX[0] =  10+(y2-1)*48;
        targetYX[1] =  36+(x2-1)*48;
        deltaY =  (( targetYX[0] - posYX[0] )/(double)ANIM_TRSHOLD);  
        deltaX =  (( targetYX[1] - posYX[1] )/(double)ANIM_TRSHOLD);          
        movingFig = fig - Chess.WHITE_KING;
        routeActive = true;
        
    } 
    

    static JFrame createAndShowGui() {
        JcompChess mainPanel = new JcompChess();

        JFrame frame = new JFrame();
        frame.setTitle("Chess");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        frame.getContentPane().add(mainPanel, BorderLayout.CENTER);

        frame.pack();
        frame.setSize(400, 400 + 50);

        frame.setVisible(true);

        return frame;
    }

    public JcompChess() {
        new Timer(5, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent actEvt) {
                
                if (repaint && !routeActive){
                    repaint();
                    repaint = false;
                }
                else if (routeActive){

                   posYX[0] += deltaY; 
                   posYX[1] += deltaX;
                   animCount++;
                   if ( animCount>=ANIM_TRSHOLD ){
                    animCount = 0; 
                    fromCoords[0] = 0;   
                    fromCoords[1] = 0; 
                    toCoords[0] = 0;
                    toCoords[1] = 0;
                Game.rMoveMarkerYX[0] = -1;
                Game.rMoveMarkerYX[1] = -1; 
                    routeActive = false;
                   }
                   repaint();
                }
                

            }
        }).start();
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(PREF_W, PREF_H);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.drawImage(background, 0, 0, null);
        for (int y = 1; y <= 8; y++) {
        for (int x = 1; x <= 8; x++) {
            if (fromCoords[0]==y & fromCoords[1]==x) continue;
            if ( y==Game.errorMarkerYX[0] && x==Game.errorMarkerYX[1] ){
                g.setColor(Color.RED);
                g.fillRect(24+(x-1)*48,(y-1)*48, 40, 42); 
                Game.errorMarkerYX[0] = -1;
                Game.errorMarkerYX[1] = -1;            
            }
            if ( routeActive && y==Game.rMoveMarkerYX[0] && x==Game.rMoveMarkerYX[1] ){
                g.setColor(Color.GREEN);
                g.fillRect(24+(x-1)*48,(y-1)*48, 40, 42);            
            }            
            
            char piece = Chess.board[y][x];
            if (toCoords[0] == y & toCoords[1]==x ) piece = targetFig;           
            if ( piece>=Chess.WHITE_KING & piece<=Chess.BLACK_PAWN ){
                int imgIndex = (int)(piece - Chess.WHITE_KING);
                g.drawImage(image.get(imgIndex), 36+(x-1)*48, 10+(y-1)*48, null);      
            }
        }
        }
        
        if ( routeActive ){

            int y= (int) posYX[0];
            int x= (int) posYX[1];
            g.drawImage(image.get(movingFig), x, y, null);
            }
        
       //g.setColor(Color.gray);
       // g.fillRect(0, 0, PREF_W, PREF_H);



    }
}
